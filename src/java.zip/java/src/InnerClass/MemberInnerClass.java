/*
 * Class inside a class but outside a method; can even access a private variable  
 */

package InnerClass;

public class MemberInnerClass {
	private int data=30;  
	class Inner{  
		void msg(){System.out.println("data is "+data);}  
	 }  
	 
	public static void main(String args[]){  
		 MemberInnerClass obj=new MemberInnerClass();  
		 MemberInnerClass.Inner in = obj.new Inner();  
	  in.msg();  
	 }  
}  


