/*
 * Regular expressions belongs to java.util.regex
 */

package Regex;
import java.util.regex.*;

public class RegexEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Pattern.matches(".s", "as"));
		System.out.println(Pattern.matches("[amn]+", "ammnmaa")); // a/m/n; +(one or more) quantifiers; *(0 or more) 
		System.out.println(Pattern.matches("\\d+", "323"));//meta characters:- d(digit); D(non digit); s(whitespace); w(word)
		System.out.println(Pattern.matches("[a-zA-Z0-9]{6}", "arun32"));//m times 
		
		
	}

}
