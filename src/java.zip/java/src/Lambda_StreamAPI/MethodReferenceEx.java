/*
 * Functional Interface:- it has only one abstract method & is annotated by @FunctionalInterface 
 * Method Reference(::):- it refers method of functional interface; no need of implementing the interface 
 * 						  it just refers the interface method   
 */


package Lambda_StreamAPI;

interface Sayable{  
    void say();  
}  


public class MethodReferenceEx {

	public static void saySomething(){  
        System.out.println("Hello, this is static method.");  
    }  
	public void eatSomething(){  
	        System.out.println("Hello, this is non-static method.");  
	 }  
    public static void main(String[] args) {  
        // Referring static method  
        Sayable sayable = MethodReferenceEx::saySomething; //method reference   
        // Calling interface method  
        sayable.say(); 
        //referring instance method 
        Sayable sayable2 = new MethodReferenceEx()::eatSomething;
        // Calling interface method
        sayable2.say();
    }  
}
