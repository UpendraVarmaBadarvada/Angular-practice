/*
 * it belongs to java.util;
 * it passes data through a pipeline of operations & source is not changed; 
 * You can use stream to filter, fetch, collect, print, and convert from one data structure to other 
 * methods are filter, map, collect(Collectors.toList), forEach, reduce, max, count
 */

package Lambda_StreamAPI;
import java.util.*;
import java.util.stream.Collectors;
public class StreamAPIEx {

	public static void main(String[] args) {  
        List<Product> productsList = new ArrayList<Product>();  
        //Adding Products  
        productsList.add(new Product(1,"HP Laptop",25000f));  
        productsList.add(new Product(2,"Dell Laptop",30000f));  
        productsList.add(new Product(3,"Lenevo Laptop",28000f));  
        productsList.add(new Product(4,"Sony Laptop",28000f));  
        productsList.add(new Product(5,"Apple Laptop",90000f)); 
        productsList.add(new Product(6,"Toshiba Laptop",30000f));
        List<Float> productPriceList2 =productsList.stream()  
                                     .filter(p -> p.price > 30000)// filtering data  
                                     .map(p->p.price)        // fetching price  
                                     .collect(Collectors.toList()); // collecting as list  
        System.out.println(productPriceList2+"\n");  
        productsList.stream()  
        .filter(product -> product.price == 30000)  
        .forEach(product -> System.out.print(product.name+"\t")); //iterating 
        
        System.out.println("\n");
        
        float totalPrice = productsList.stream()  
                .map(product->product.price)  
                .reduce(0.0f,(sum, price)->sum+price);   // accumulating price  
        System.out.println("total is "+totalPrice+"\n");  
        
        Product productA = productsList.stream()  
                .max((product1, product2)->   
                product1.price > product2.price ? 1: -1).get();  //max; <:-min
        System.out.println(productA.name+":"+productA.price+"\n");
        
        long count = productsList.stream()  
                .filter(product->product.price<30000)  
                .count();  //count
        System.out.println("count is: "+count+"\n");  
 	
	
	}  
	
}
