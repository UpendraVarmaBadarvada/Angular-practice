/*
 * Lambda expressions are like solution to method reference 
 * no definition only implementation; 
 */


package Lambda_StreamAPI;

interface Drawable{  
    public String draw(int width);  
}  
public class LambdaExpressions{  

	public static void main(String[] args) {  
		Drawable s=(int width)->{  
		String s1="Width is ";
        String s2=s1+width;
        return s2;
		};  
		System.out.println(s.draw(10));  
	}  
}  
