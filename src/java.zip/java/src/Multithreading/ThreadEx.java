/*
 * Execute multiple threads(light weight process) simultaneously sharing memory 
 * with context switching; doesn't block the users as they are independent; 
 * thread is executed inside the process; a process can have multiple threads 
 * Thread class extends Object class and implement Runnable interface 
 * Thread life cycle:- new(start)->runnable(run)->running->non runnable(blocked)->terminated
 * blocked:- sleep, block on i/o, wait, wait for lock, suspend
 * blocked->runnable:- sleep over, i/o complete, lock available, resume, notify/notifyAll
 * runnable->running:- scheduling(preemptive(priority), time slicing)
 * always execute run() outside main thread
 * only run start once               
 */

package Multithreading;

public class ThreadEx extends Thread {
	public void run() {
		System.out.println("Thread running is:"+Thread.currentThread().getName());
	}      
	public static void main(String[] args) {
		ThreadEx t1=new ThreadEx();
		t1.start();
	}

}
