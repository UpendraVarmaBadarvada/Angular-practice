package Multithreading;

public class RunnableEx implements Runnable {
	public void run() {
		System.out.println("This is a new Thread");
	}
	public static void main(String[] args) {
		RunnableEx r1= new RunnableEx();
		Thread t1 = new Thread(r1);
		t1.start();
	}

}
