/*
 * sleep is used for context switching; 
 * Join suspends the current running thread until the thread joined is executed 
 */
 

package Multithreading;

class SleepJoinEx extends Thread {
	public void run() {
		for(int i=0; i<5;i++) {
			try {
				Thread.sleep(2500);
			}catch(InterruptedException ex) {
				System.out.println("Exception occurs");
			}
			System.out.println("number is :"+i);
		}
	}
	public static void main(String[] args) {
		SleepJoinEx e1 = new SleepJoinEx();
		SleepJoinEx e2 = new SleepJoinEx();
		SleepJoinEx e3 = new SleepJoinEx(); 
		e1.start();
		try {
			e1.join();
		}catch(Exception ex) {
			System.out.println("this is an exception");
		}
		e2.start();
		e3.start();
		
	}

}
