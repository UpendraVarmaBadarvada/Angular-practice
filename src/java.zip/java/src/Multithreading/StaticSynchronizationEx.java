/*
 * lock on class not on object especially on static method so no need of instantiation 
 * of the resource 
 * 
 */
package Multithreading;

class MyTable{  
	synchronized static void printTable(int n){  
		for(int i=1;i<=10;i++){  
			System.out.println(n*i);  
			try{  
				Thread.sleep(400);  
			}catch(Exception e){}  
		}  
	 }  
}  
	  
class MineThread1 extends Thread{  
	public void run(){  
		MyTable.printTable(1);  
	}  
}  
	  
class MineThread2 extends Thread{  
	public void run(){  
		MyTable.printTable(10);  
	}  
}  
	  
class MineThread3 extends Thread{  
	public void run(){  
		MyTable.printTable(100);  
	}  
}  
	  
class MineThread4 extends Thread{  
	public void run(){  
		MyTable.printTable(1000);  
	}  
}  
	  
public class StaticSynchronizationEx{  
	public static void main(String t[]){  
		MineThread1 t1=new MineThread1();  
		MineThread2 t2=new MineThread2();  
		MineThread3 t3=new MineThread3();  
		MineThread4 t4=new MineThread4();  
		t1.start();  
		t2.start();  
		t3.start();  
		t4.start();  
	}  
}  
