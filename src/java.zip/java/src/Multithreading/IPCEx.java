/*
 * Acquiring and releasing locks 
 * release:- wait; re acquire:-notify, notifyAll 
 */

package Multithreading;

class Customer{  

	int amount=10000;  
  
	synchronized void withdraw(int amount){  
		System.out.println("going to withdraw...");  
  
		if(this.amount<amount){  
			System.out.println("Less balance; waiting for deposit...");  
			try{wait();}catch(Exception e){}  
		}  
		this.amount-=amount;  
		System.out.println("withdraw completed...");  
	}  
  

	synchronized void deposit(int amount){  
		System.out.println("going to deposit...");  
		this.amount+=amount;  
		System.out.println("deposit completed... ");  
		notify();  
	}  
} 

class IPCThread1 extends Thread{
	Customer c;
	IPCThread1(Customer c){
		this.c = c;
	}
	public void run() {
		c.withdraw(15000);
	}
	
}

class IPCThread2 extends Thread{
	Customer c;
	IPCThread2(Customer c){
		this.c = c;
	}
	public void run() {
		c.deposit(10000);
	}
	
}
  
public class IPCEx{  
	public static void main(String args[]){  
		Customer c=new Customer();  
		IPCThread1 t1 = new IPCThread1(c);
		IPCThread2 t2 = new IPCThread2(c);
		t1.start();
		t2.start();
}}  
