
public class ArrayEx {
	public static void main(String[] args) {
		int [] a = {3,5,7,9};
		for(int i:a) {  //for each loop 
			System.out.println(i); 
		}
	}
}
