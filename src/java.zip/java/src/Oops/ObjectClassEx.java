/*
 * class:- instance variables and methods 
 * Object:- instance of a class
 * Access Specifiers:- public,private(only in class), protected(only by child), 
 * 					   default(only in project)
 * Object class:- wait, notify, notifyAll, equals, hashcode, clone, toString, finalize  
 * unreferenced objects are collected and removed by garbage collector 
 * 
 */

package Oops;

class Simple{
	
}

public class ObjectClassEx {
	
	int length;
	int width;
	
	void insert(int l, int w) {
		length = l;
		width = w;
	}
	
	void calcArea() {
		System.out.println(length*width);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ObjectClassEx obj = new ObjectClassEx();
		obj.insert(5, 6);
		obj.calcArea();
		
	}
	
}


