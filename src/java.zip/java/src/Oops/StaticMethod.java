/*
 * Belongs to class only not object so no need to instantiate it
 * 
 */

package Oops;

class StaticMethod {
	
	int age;
	String name;
	static String college = "DSU";
	
	static void company() {
		System.out.println("I work at RBEI");
		college = "GDV";
	}
	
	StaticMethod(int i, String n){
		age=i;
		name=n;
	}
	
	void printName() {
		System.out.println(age+" & "+name+" & "+college);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticMethod c = new StaticMethod(26,"upendra");
		c.printName();
		StaticMethod.company();
		c.printName();
		
	}
}
