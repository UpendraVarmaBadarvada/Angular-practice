/*
 * Aggregation:- has a relation
 */

package Oops;

class Address {  
	
	String city,state,country;  
  
	public Address(String city, String state, String country) {  
		this.city = city;  
		this.state = state;  
		this.country = country;  
	}  
}



public class Aggregation {
	int id;  
	String name;  
	Address address;   
	  
	public Aggregation(int id, String name,Address address) {  
	    this.id = id;  
	    this.name = name;  
	    this.address=address;  
	}  
	  
	void display(){  
	System.out.println(id+" "+name);  
	System.out.println(address.city+" "+address.state+" "+address.country);  
	}  
	  
	public static void main(String[] args) {  
	Address address1=new Address("gdv","AP","india");  
	Address address2=new Address("gdv","AP","india");  
	
	//aggregation 
	Aggregation e=new Aggregation(1,"uppi",address1);  
	Aggregation e2=new Aggregation(2,"arjun",address2);  
	      
	e.display();  
	e2.display();  
	      
	}  
}
