package Oops;

class Student{

	int age;
	String name;
	String Company;
	
	Student(int age, String name, String company){
		this.age = age;
		this.Company = company;
		this.name = name; 
	}
	
	public String toString() {
		return this.age+" "+this.Company+" "+this.name;
	}
}
public class ToStringEx {
	public static void main(String[] args) {
		Student s1 = new Student(27,"upendra","Bosch");
		Student s2 = new Student(24,"mahima","Bosch");
		System.out.println(s1);
		System.out.println(s2);
	}

}
