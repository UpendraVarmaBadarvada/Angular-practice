/* dynamic polymorphism or run time polymorphism  
 * an overridden method is called through the reference variable of a superclass. 
 * The determination of the method to be called is based on the object being referred to 
 * by the reference variable also called upcasting and also called late binding where 
 * object type known at runtime  
 * 
 */
package Oops;

class Shape{  
	void draw(){System.out.println("drawing...");}  
}  

class Rectangle extends Shape{  
	void draw(){System.out.println("drawing rectangle...");}  
}  

class Circle extends Shape{  
	void draw(){System.out.println("drawing circle...");}  
}  

class Triangle extends Shape{  
	void draw(){System.out.println("drawing triangle...");}  
}  

public class DynamicPolymorphism{  
	public static void main(String args[]){  
		Shape s;  
		s=new Rectangle();  
		s.draw();  
		s=new Circle();  
		s.draw();  
		s=new Triangle();  
		s.draw();  
	}  
}  
