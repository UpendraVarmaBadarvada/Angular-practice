/* Inheritance:- base, child; IS-A relation
 * Single, Hierarchical, multilevel 
 * multiple not supported 
 */

package Oops;

class Base{
	void walk() {
		System.out.println("i am walking");
	}
}

class Child1 extends Base{
	void eat() {
		System.out.println("i am eating");
	}
}

class Child2 extends Child1{
	void drink() {
		System.out.println("i am drinking");
	}
}


public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child2 c2 = new Child2();
		c2.drink();
		c2.eat();
		c2.walk();
	}

}
