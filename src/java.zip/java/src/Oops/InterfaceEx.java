/*
 * Interface has public static final variables and abstract, private method definitions, 
 * default methods(method implementation) given by default keyword  
 * interface can extend another interface 
 * Interface with no member is marked interface(Serializable, cloneable)
 */

package Oops;

interface Banks{  

	float rateOfInterest();  
}  

class SB implements Banks{  

	public float rateOfInterest(){return 9.15f;}  
}  

class BOB implements Banks{  

	public float rateOfInterest(){return 9.7f;}  
}  

public class InterfaceEx {

	public static void main(String[] args){  
		Banks b=new SB();  
		System.out.println("ROI: "+b.rateOfInterest());  
	}
}
