/*
 * Wrapper classes:- Objects of primitive data types 
 * auto boxing and unboxing is auto conversion b/w primitives and objects  
 * They are Boolean, character, Byte, Short, Integer, Long, Float, Double  
 */
package Oops;

public class WrapperClasses {
	public static void main(String args[]){  
		//Converting int into Integer and Integer to int   
		int a=20;  
		
		Integer j=a; 
		
		int i = j;
		  
		System.out.println(a+" "+j+" "+i);  
		}

}
