/*
 * constructor:- initialize class same name as class;
 * can't be abstract, static, final and synchronized 
 * 
 */

package Oops;

class Constructor {
	
	int age;
	String name;
	
	Constructor(int i, String n){
		age=i;
		name=n;
	}
	
	void printName() {
		System.out.println(age+" & "+name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Constructor c = new Constructor(26,"upendra");
		c.printName();

	}

}
