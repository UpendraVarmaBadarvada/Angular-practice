/*
 * String Buffer is mutable and synchronized; 
 * 
 * String Builder is mutable but not synchronized; 
 *  
 *  Their methods are insert, delete, reverse
 */

package String;

public class StringBufferBuilderEx {
	public static void main(String [] args) {
		StringBuffer sb = new StringBuffer("upendra");
		sb.append(" is cool");// insert at a given position 
		StringBuilder sb1 = new StringBuilder("Harindra");
		sb1.append(" is cool"); 
		System.out.println(sb+","+sb1);
		
	}

}
