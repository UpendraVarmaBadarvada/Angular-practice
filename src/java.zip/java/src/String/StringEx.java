/*
 * String is immutable and it implements CharSequence, Serializable interface; 
 * strings will be stored in String constant pool(heap) and referenced from there 
 * immutable means when string is changed a new Object is created    
 */


package String;

public class StringEx {
	
	public static void main(String[] args) {
		String s = "Upendra Varma";
		String a = s + " is cool"; 
		System.out.println(a.substring(8, a.length()));
		System.out.println(a.charAt(a.length()-4));
		System.out.println(a.contains("varma"));
		System.out.println("index of "+a.charAt(a.length()-7)+" is "+a.indexOf(a.length()-7));
		System.out.println(a.replace("Upendra", "Harindra"));
		String arr[] = a.split(" ");
		for(String i:arr) {
			System.out.println(i);
			
		}
		System.out.println("name starts with U "+a.startsWith("U"));//endsWith
		System.out.println(a.toUpperCase());
		System.out.println("  upendra".trim());
		System.out.println(String.valueOf(56));
		
		
		
		
		
		
		
	}

}
