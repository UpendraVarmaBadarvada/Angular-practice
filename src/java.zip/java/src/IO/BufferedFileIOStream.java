/* 
 * In java IO is handled two ways byte oriented and char oriented
 * stream is a sequence of bytes 
 * in files buffer is used to increase performance of reading & writing;
 * We can use Data IO Stream if we have to read or write primitive data types 
 * instead of converting them in to bytes and sending them    
 */


package IO;
import java.io.*;

public class BufferedFileIOStream {

	public static void main(String[] args) {
		try {
			FileOutputStream fout=new FileOutputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/testout.txt");    
			BufferedOutputStream bout=new BufferedOutputStream(fout);    
			String s="Welcome to javaTpoint.";    
			byte b[]=s.getBytes();    
			bout.write(b);    
			bout.flush();// flush the buffer;     
			bout.close();    
			fout.close();    
			System.out.println("successfully written");
			FileInputStream fin=new FileInputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/testout.txt");    
		    BufferedInputStream bin=new BufferedInputStream(fin);    
		    int i;    
		    while((i=bin.read())!=-1){    
		     System.out.print((char)i);
		    }
		    System.out.println(" ");
		    bin.close();    
		    fin.close();
		    System.out.println("successfully read");
		}catch(Exception exc) {
			exc.printStackTrace();
		}
	}
}
