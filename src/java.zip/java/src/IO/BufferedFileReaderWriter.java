/*
 * char oriented
 * CharArrayWriter:- writing to multiple streams 
 */

package IO;
import java.io.*;

public class BufferedFileReaderWriter {
	public static void main(String[] args) {
		try {
		FileWriter writer = new FileWriter("/Users/upendravarma/passion/Java/Core Java/Basics/files/test1out.txt");  
	    BufferedWriter buffer = new BufferedWriter(writer);  
	    buffer.write("Welcome to javaTpoint.");  
	    buffer.close();  
	    System.out.println("Successfully written");
	    
	    FileReader fr=new FileReader("/Users/upendravarma/passion/Java/Core Java/Basics/files/test1out.txt");    
        BufferedReader br=new BufferedReader(fr);    
	    int i;    
        while((i=br.read())!=-1){  
        System.out.print((char)i);  
        }
        System.out.println(" ");
        System.out.println("Successfully written");
        br.close();    
        fr.close();    
		}catch(Exception exc) {
			System.out.println("Exception occured");
		}
	}
}
