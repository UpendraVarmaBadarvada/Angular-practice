package IO;
import java.io.*; 

public class ByteToAndFromCharecterStream {

	public static void main(String[] args) {
		try {  
            OutputStream outputStream = new FileOutputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/file.txt");  
            Writer writer = new OutputStreamWriter(outputStream);  
            writer.write("Hello World");  
            writer.close();  
            System.out.println("charecter to byte");
            
            InputStream stream = new FileInputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/file.txt");  
            Reader reader = new InputStreamReader(stream);  
            int i;    
		    while((i=reader.read())!=-1){    
                System.out.print((char)i);    
            } 
		    System.out.println(" ");
            System.out.println("byte to charecter");
        } catch (Exception e) {  
            e.getMessage();  
        }
	}
}
