/*
 * Writing and reading from multiple streams 
 */


package IO;

import java.io.*;
public class MultipleIOStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileOutputStream fout1=new FileOutputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/f1.txt");    
			FileOutputStream fout2=new FileOutputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/f2.txt");    
	        
			ByteArrayOutputStream bout=new ByteArrayOutputStream();    
			String s="Welcome to javaTpoint.";    
			byte b[]=s.getBytes();  
			bout.write(b);    
			bout.writeTo(fout1);    
			bout.writeTo(fout2);    
	        
			bout.flush();    
			bout.close();    
			System.out.println("Successfully written to multiple streams");  
			
			FileInputStream input1=new FileInputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/f1.txt");    
			FileInputStream input2=new FileInputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/f2.txt"); 
			FileOutputStream fout=new FileOutputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/f3.txt");
			SequenceInputStream inst=new SequenceInputStream(input1, input2);    
			int j;    
			while((j=inst.read())!=-1){     
				fout.write(j);
				System.out.print((char)j);
			}
			System.out.println(" ");
			inst.close();    
			input1.close();    
			input2.close();
			System.out.println("Successfully read from multiple streams"); 
		}catch(Exception exc) {
			
		}

	}

}
