/*
 * Serialization is the process of writing state of an object into a byte stream; its mainly used in 
 * Hibernate, EJB, JPA; reverse process byte stream into object is called deserialization.   
 * static variables are not serializable; 
 * transient keyword makes a data member non serializable & it returns a value 0;  
 */


package IO;
import java.io.*; 

public class SerializationEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{  
			  //Creating the object  
			  Student s1 =new Student(211,"ravi");    
			  //Creating stream and writing the object  
			  FileOutputStream fout=new FileOutputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/ser.txt");  
			  ObjectOutputStream out=new ObjectOutputStream(fout);  
			  out.writeObject(s1);  
			  out.flush();  
			  out.close();  
			  System.out.println("successfully serialized");
			  FileInputStream fin=new FileInputStream("/Users/upendravarma/passion/Java/Core Java/Basics/files/ser.txt");  
			  ObjectInputStream in=new ObjectInputStream(fin);  
			  Student s=(Student) in.readObject();  
			  //printing the data of the serialized object  
			  System.out.println(s.id+" "+s.name);  
			  //closing the stream  
			  in.close(); 
			  System.out.println("successfully deserialized");
			  }
		catch(Exception e){System.out.println(e);}  

	}

}
