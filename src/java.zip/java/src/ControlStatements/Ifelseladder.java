package ControlStatements;
import java.util.*;
public class Ifelseladder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("please enter a number");
		Scanner in = new Scanner(System.in);
		int a = in.nextInt();
		if(a>0) {
			System.out.println("positive");
		}
		else if(a<0) {
			System.out.println("negative");
		}
		else {
			System.out.println("zero");
		}

	}

}
