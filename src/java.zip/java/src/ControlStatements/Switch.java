package ControlStatements;
import java.util.*;

public class Switch {
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a charecter");
		char letter= in.next().charAt(0);
		switch(letter) {
		case 'a':
			System.out.println("vowel");
			break;
		case 'e':
			System.out.println("vowel");
			break;
		case 'i':
			System.out.println("vowel");
			break;
		case 'o':
			System.out.println("vowel");
			break;
		case 'u':
			System.out.println("vowel");
			break;
		default:
			System.out.println("consonent");
		
		}
	}

}
