/**
 * 
 */

/**
 * J2SE, J2EE, J2ME 
 * JVM, JDK, JRE
 * Byte code, class, platform independent, portable
 * CLASSLOADER, BYTE CODE VERIFIER, STACK, HEAP, CLASS AREA
 * data types:- primitive(boolean, char, short, integer, long, float, double)
 *              non primitive:- String, Array
 * operators:- ++,--; +,-*,/; <,>,<=,>=,==,!=, &&,||, ?:, +=,-=,*=,/=
 * integer->float(widening); float->integer(shortening/type casting());               
 *   
 * 
 */
public class HelloUppi {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("I am uppi dada");

	}

}
