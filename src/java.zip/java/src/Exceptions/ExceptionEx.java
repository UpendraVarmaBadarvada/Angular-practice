/*
 * java.lang.throwable is the super class
 * abnormal condition 
 * checked(compile time), unchecked(run time) exceptions and errors
 * checked:- IO, SQL, ClassNotFoundException 
 * unchecked:- Arithmetic, NullPointer, NumberFormat, IndexOutOfBound 
 * try, catch, finally, throw, throws   
 * finally:- executes always even if exception there or not except System.exit(); 
 * If the superclass method declares an exception subclass overridden method can declare 
 * same, subclass exception or no exception but cannot declare parent exception. 
 */


package Exceptions;

public class ExceptionEx {
	
	public static void main(String[] args) {  
        
        try{    
             int a[]=new int[5];    
             a[5]=30/0;    
             System.out.println(a[10]);  
            }    
            catch(ArithmeticException e)  
               {  
                System.out.println("Arithmetic Exception occurs");  
               }    
            catch(ArrayIndexOutOfBoundsException e)  
               {  
                System.out.println("ArrayIndexOutOfBounds Exception occurs");  
               }    
            catch(Exception e)  
               {  
                System.out.println("Parent Exception occurs");  
               } 
        	finally {
        		System.out.println("Its used to release resources/clean up"); 
        	}
            System.out.println("rest of the code");    
 }  

}
