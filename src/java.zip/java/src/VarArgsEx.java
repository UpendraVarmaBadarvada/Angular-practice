/*
 * Variable arguments acts just like rest or spread operator in java script 
 * it should be the last argument in the function 
 */
public class VarArgsEx {

	public static void func(Integer... values) {
		for(Integer s:values) {
			System.out.print(s);
			System.out.print("\t");
		}
		System.out.println(" ");
	}
	
	public static void main(String[] args) {
		func(1);
		func(1,2,3,4);
		
	}
}
