/*
 * properties file is used to store properties of resources like db, etc 
 * it stores key,value pairs of strings 
 */
package Collections;
import java.util.*;
import java.io.*;

public class PropertiesEx {
	public static void main(String[] args) {
		Properties p=new Properties();  
		p.setProperty("name","Sonoo Jaiswal");  
		p.setProperty("email","sonoojaiswal@javatpoint.com");  
		try {
			p.store(new FileWriter("/Users/upendravarma/passion/Java/Core Java/Basics/files/info.properties"),"Javatpoint Properties Example");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		Properties p1=new Properties(); 
	    try {
			p1.load(new FileReader("/Users/upendravarma/passion/Java/Core Java/Basics/files/info.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	      
	    System.out.println(p1.getProperty("name"));  
	    System.out.println(p1.getProperty("email"));  
	}
}
