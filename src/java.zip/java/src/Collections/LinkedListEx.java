/*
 * Linked List implements both list and dequeue so it acts as a doubly linked list 
 * other methods are set,get,remove,clear;  
 */

package Collections;

import java.util.*;



public class LinkedListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Book> ll=new LinkedList<Book>();  
		
		Book b1=new Book(101,"Let us C","Yashwant Kanetkar","BPB",8);  
	    Book b2=new Book(102,"Data Communications and Networking","Forouzan","Mc Graw Hill",4);  
	    Book b3=new Book(103,"Operating System","Galvin","Wiley",6);  
	    
	    ll.add(b1);
	    ll.add(b2);
	    ll.add(b3);
	    
	    Iterator<Book> iter = ll.descendingIterator();
	    while(iter.hasNext()) {
	    	Book bb1 = iter.next();
	    	System.out.println(bb1.author+" "+bb1.id+" "+bb1.name+" "+bb1.publisher+" "+bb1.quantity);
	    }
		
		

	}

}

