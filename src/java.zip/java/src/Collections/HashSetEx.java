/*
 * uses Hashing for insertion & set which means it has unique elements  
 * implements set interface 
 */

package Collections;
import java.util.*;

public class HashSetEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Book> l=new HashSet<Book>(); //generic type   
		
		Book b1=new Book(101,"Let us C","Yashwant Kanetkar","BPB",8);  
	    Book b2=new Book(102,"Data Communications and Networking","Forouzan","Mc Graw Hill",4);  
	    Book b3=new Book(103,"Operating System","Galvin","Wiley",6);  
	    
	    l.add(b1);
	    l.add(b2);
	    l.add(b3);
	    
	    //iterating 
	    Iterator<Book> iter = l.iterator();
	    while(iter.hasNext()) {
	    	Book bb1 = iter.next();
	    	System.out.println(bb1.author+" "+bb1.id+" "+bb1.name+" "+bb1.publisher+" "+bb1.quantity);
	    }
		
		

	}
}
