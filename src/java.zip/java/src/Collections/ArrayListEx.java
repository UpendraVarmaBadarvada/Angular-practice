/*
 * Collections:- group of objects 
 * ArrayList:- Iterator->Collection->List interfaces; used for random access & maintains insertion order; 
 * Generics:- type safety; compile time checking; We can have type inference(<>) 
 *  
 */


package Collections;
import java.util.*;



public class ArrayListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Book> l=new ArrayList<>(); //generics & type inference    
		
		Book b1=new Book(101,"Let us C","Yashwant Kanetkar","BPB",8);  
	    Book b2=new Book(102,"Data Communications and Networking","Forouzan","Mc Graw Hill",4);  
	    Book b3=new Book(103,"Operating System","Galvin","Wiley",6);  
	    
	    l.add(b1);
	    l.add(b2);
	    l.add(b3);
	    
	    //iterating 
	    Iterator<Book> iter = l.iterator();
	    while(iter.hasNext()) {
	    	Book bb1 = iter.next();
	    	System.out.println(bb1.author+" "+bb1.id+" "+bb1.name+" "+bb1.publisher+" "+bb1.quantity);
	    }
		
		

	}

}
