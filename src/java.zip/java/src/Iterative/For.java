package Iterative;
import java.util.*;

public class For {
	public static void main(String [] args) {
		//prime
		boolean an = true;
		Scanner in = new Scanner(System.in);
		System.out.println("enter a number");
		int a = in.nextInt();
        for(int i = 2; i <= a/2; ++i)
        {
            // condition for nonprime number
            if(a % i == 0)
            {
                an = false;
                break;
            }
        }

        if (an==true)
            System.out.println(a + " is a prime number.");
        else
            System.out.println(a + " is not a prime number.");
    

	}

}
