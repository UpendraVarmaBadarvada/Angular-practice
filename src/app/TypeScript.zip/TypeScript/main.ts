//typescript 
//tsc main --watch

let name:string = "Upendra Varma";
let age:number = 26;
let male:boolean = true
let list:number[] = [1,2,3,4,5];
let list1:Array<number> = [6,7,8,9]; //generic 
let list2:[string,number] = ['upendra',26]; //tuple
enum Color {Red,Green=5,Blue};
let c:Color = Color.Green;
let random:any;
random = 26;
console.log(random);
random = 'upendra';
console.log(random);
console.log(name, age, male, list, list1, list2, c)
let multitype:number | string; //union type using pipe operator 
multitype = 26;
console.log(multitype);
multitype = 'upendra'
console.log(multitype);
function add(number1:number, number2:number,number3?:number):number{
    return number1 + number2; // ? indicates optional parameter 
}
console.log(add(1,2));

//interface
interface Person{
    firstName:string;
    lastName:string;
}

function display(person:Person){
    console.log(`My first name is ${person.firstName} and my last name is ${person.lastName}`);
}

display({
    firstName:'upendra',
    lastName:'varma'
});

//class
class Employee{
    constructor(protected employeeName:string,private readonly employeeId:string){
    }
    greet(){
        console.log(`my empid is ${this.employeeId}`);
    }
}

export class Engineer extends Employee{
    designation:string;
    constructor(employee:string,id:string,designation:string){
        super(employee,id);
        this.designation = designation;
    }
    work(){
        console.log(`my employeeid is ${this.employeeName} and designation is ${this.designation}`);
    }
    static enjoy(hobby:string){
        console.log(`my favourite hobby is ${hobby}`);
    }
}

let emp1 = new Engineer('upendra','bud4kor','SSE');
emp1.greet();
emp1.work();
Engineer.enjoy('coding');

//arrow fns
const arr = (a:number,b:number) => (a+b)/2;
console.log(arr(10,20));

//rest op(fn def) & spread op(fn call)

export function restFunction(message:string,...arr:string[]){
    console.log(message);
    for(let i in arr){console.log(arr[i]);}
}
let array:string[] = ['python','javascript','angular','java'];
restFunction('upendra',...array);

// object literal 
function concat(firstname:string,lastname:string){
    var fullname = firstname + lastname;
    return {fullname,firstname,lastname};
}
let p = concat('upendra','varma');
console.log(p.firstname,p.lastname,p.fullname);

//array destructuring 
let [ind,...el] = array;
console.log(ind,el);

//object destructuring 
let {firstname,lastname,fullname} = p;
console.log(firstname,lastname,fullname);

for(let i in p){
    console.log(i,':',p[i]);
}

//closure & self invoking method   
const closure = function (firstNumber:number,secondNumber:number){
    const diff= 50;
    return function inner(thirdNumber:number){
        return (firstNumber + secondNumber + thirdNumber) - diff; 
    }
};

console.log(closure(25,25)(50));


//call backs which execute at the end of event loop with an async call of setTimeout 
console.log('<------------------->')

const posts:string[] = ['Hi','Hello','Bye'];
function getPosts(){
    setTimeout(()=>{
        let output = "";
        posts.forEach(post=>output+=`;${post}`);
        console.log(output.substring(1,output.length));
    },1000);
}

function createPost(post:string,callback:any){
    setTimeout(()=>{
        posts.push(post);
        callback();
    },2000);
}

createPost('Welcome',getPosts);

// promises to resolve call back hell 
function fetchPost(post:string){
    return new Promise((resolve,reject)=>setTimeout(()=>{
        posts.push(post);
        const err = false;
        if(!err){
            resolve();
        }
        else{
            reject('Oops something is wrong');
        }
    },5000));
}

fetchPost('Hurray').then(getPosts).catch(err=>console.log(err));

const date = new Date();
console.log(`today is ${date.getDate()}`); 
console.log(`now time is ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`);

//regex & exception handling(try,catch,throw,Error)
function regexTest(number:string,email:string){
var reg1 = /^[7-9]\d{9}$/;
var reg2 = /^([a-zA-Z0-9]+)@([a-zA-Z0-9\.]+)$/;
if(reg1.test(number) && reg2.test(email)){
    console.log('valid mobile number and email id');
}
else{
    throw new Error('Invalid user name and email id');
}
}
(function main(){
    try{
        regexTest('8886183899','upendravarma1993@gmail.com');
    }
    catch(error){
        console.log(error.message);
    }
})();








