import {Engineer, restFunction} from './main';

console.log('<------------------->')
let emp1 = new Engineer('upendra','bud4kor','SSE');
emp1.greet();
emp1.work();
Engineer.enjoy('coding');

let array:string[] = ['python','javascript','angular','java'];
restFunction('upendra',...array);

//array higher order functions 
console.log('<------------------->')
array.forEach((element,index)=>console.log(index,":",element));
let numbers:number[] = [1,5,9,15,25,5];
let numbers_mapped = numbers.map(num=>num+5);
let numbers_filtered = numbers.filter(num=>num<=5);
let reduced_sum = numbers.reduce((first,last)=>first+last);
let every_num = numbers.every(num=>num<=5)
let some_num = numbers.some(num=>num<=5)
let even_numbers = numbers.find(number=>number%5 === 0); 
let even_numbers_index = numbers.findIndex(number=>number%5 === 0); 
console.log(numbers_mapped,numbers_filtered,reduced_sum,every_num,some_num);
console.log(numbers.sort())
console.log(even_numbers,even_numbers_index);
console.log(`last number is ${numbers[numbers.length-1]}`)
//unique array
console.log(Array.from(new Set(numbers)))

function isPrime(number){
    for(let i=2;i<=numbers.length/2;i--){
        if(number%i == 0){
            console.log(`${number} is composite`);
            break;
        }
        else{
            console.log(`${number} is prime`);
            break;
        } 
    }
}
isPrime(10);





