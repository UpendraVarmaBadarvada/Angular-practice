//ajax api call with fetch api & async await which waits for a promise to either resolve or reject

const fetch = require('node-fetch');

async function getRecipe(query){
const res = await fetch(`https://forkify-api.herokuapp.com/search?q=${query}`);
const data  = await res.json();
return data;
}
getRecipe('popcorn').then(data=>{
    console.log('<----------------------------------------------------->')
    for(let ind in data.recipes){
        console.log(`The recipe name is ${data.recipes[ind]['title']}`);
    }
}).catch(err=>console.log(err.message));
    

  
  
  