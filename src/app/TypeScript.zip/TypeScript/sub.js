"use strict";
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
exports.__esModule = true;
var main_1 = require("./main");
console.log('<------------------->');
var emp1 = new main_1.Engineer('upendra', 'bud4kor', 'SSE');
emp1.greet();
emp1.work();
main_1.Engineer.enjoy('coding');
var array = ['python', 'javascript', 'angular', 'java'];
main_1.restFunction.apply(void 0, __spreadArrays(['upendra'], array));
//array higher order functions 
console.log('<------------------->');
array.forEach(function (element, index) { return console.log(index, ":", element); });
var numbers = [1, 5, 9, 15, 25, 5];
var numbers_mapped = numbers.map(function (num) { return num + 5; });
var numbers_filtered = numbers.filter(function (num) { return num <= 5; });
var reduced_sum = numbers.reduce(function (first, last) { return first + last; });
var every_num = numbers.every(function (num) { return num <= 5; });
var some_num = numbers.some(function (num) { return num <= 5; });
var even_numbers = numbers.find(function (number) { return number % 5 === 0; });
var even_numbers_index = numbers.findIndex(function (number) { return number % 5 === 0; });
console.log(numbers_mapped, numbers_filtered, reduced_sum, every_num, some_num);
console.log(numbers.sort());
console.log(even_numbers, even_numbers_index);
console.log("last number is " + numbers[numbers.length - 1]);
//unique array
console.log(Array.from(new Set(numbers)));
function isPrime(number) {
    for (var i = 2; i <= numbers.length / 2; i--) {
        if (number % i == 0) {
            console.log(number + " is composite");
            break;
        }
        else {
            console.log(number + " is prime");
            break;
        }
    }
}
isPrime(10);
