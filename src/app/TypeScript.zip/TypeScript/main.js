"use strict";
//typescript 
//tsc main --watch
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
exports.__esModule = true;
exports.restFunction = exports.Engineer = void 0;
var name = "Upendra Varma";
var age = 26;
var male = true;
var list = [1, 2, 3, 4, 5];
var list1 = [6, 7, 8, 9]; //generic 
var list2 = ['upendra', 26]; //tuple
var Color;
(function (Color) {
    Color[Color["Red"] = 0] = "Red";
    Color[Color["Green"] = 5] = "Green";
    Color[Color["Blue"] = 6] = "Blue";
})(Color || (Color = {}));
;
var c = Color.Green;
var random;
random = 26;
console.log(random);
random = 'upendra';
console.log(random);
console.log(name, age, male, list, list1, list2, c);
var multitype; //union type using pipe operator 
multitype = 26;
console.log(multitype);
multitype = 'upendra';
console.log(multitype);
function add(number1, number2, number3) {
    return number1 + number2; // ? indicates optional parameter 
}
console.log(add(1, 2));
function display(person) {
    console.log("My first name is " + person.firstName + " and my last name is " + person.lastName);
}
display({
    firstName: 'upendra',
    lastName: 'varma'
});
//class
var Employee = /** @class */ (function () {
    function Employee(employeeName, employeeId) {
        this.employeeName = employeeName;
        this.employeeId = employeeId;
    }
    Employee.prototype.greet = function () {
        console.log("my empid is " + this.employeeId);
    };
    return Employee;
}());
var Engineer = /** @class */ (function (_super) {
    __extends(Engineer, _super);
    function Engineer(employee, id, designation) {
        var _this = _super.call(this, employee, id) || this;
        _this.designation = designation;
        return _this;
    }
    Engineer.prototype.work = function () {
        console.log("my employeeid is " + this.employeeName + " and designation is " + this.designation);
    };
    Engineer.enjoy = function (hobby) {
        console.log("my favourite hobby is " + hobby);
    };
    return Engineer;
}(Employee));
exports.Engineer = Engineer;
var emp1 = new Engineer('upendra', 'bud4kor', 'SSE');
emp1.greet();
emp1.work();
Engineer.enjoy('coding');
//arrow fns
var arr = function (a, b) { return (a + b) / 2; };
console.log(arr(10, 20));
//rest op(fn def) & spread op(fn call)
function restFunction(message) {
    var arr = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        arr[_i - 1] = arguments[_i];
    }
    console.log(message);
    for (var i in arr) {
        console.log(arr[i]);
    }
}
exports.restFunction = restFunction;
var array = ['python', 'javascript', 'angular', 'java'];
restFunction.apply(void 0, __spreadArrays(['upendra'], array));
// object literal 
function concat(firstname, lastname) {
    var fullname = firstname + lastname;
    return { fullname: fullname, firstname: firstname, lastname: lastname };
}
var p = concat('upendra', 'varma');
console.log(p.firstname, p.lastname, p.fullname);
//array destructuring 
var ind = array[0], el = array.slice(1);
console.log(ind, el);
//object destructuring 
var firstname = p.firstname, lastname = p.lastname, fullname = p.fullname;
console.log(firstname, lastname, fullname);
for (var i in p) {
    console.log(i, ':', p[i]);
}
//closure & self invoking method   
var closure = function (firstNumber, secondNumber) {
    var diff = 50;
    return function inner(thirdNumber) {
        return (firstNumber + secondNumber + thirdNumber) - diff;
    };
};
console.log(closure(25, 25)(50));
//call backs which execute at the end of event loop with an async call of setTimeout 
console.log('<------------------->');
var posts = ['Hi', 'Hello', 'Bye'];
function getPosts() {
    setTimeout(function () {
        var output = "";
        posts.forEach(function (post) { return output += ";" + post; });
        console.log(output.substring(1, output.length));
    }, 1000);
}
function createPost(post, callback) {
    setTimeout(function () {
        posts.push(post);
        callback();
    }, 2000);
}
createPost('Welcome', getPosts);
// promises to resolve call back hell 
function fetchPost(post) {
    return new Promise(function (resolve, reject) { return setTimeout(function () {
        posts.push(post);
        var err = false;
        if (!err) {
            resolve();
        }
        else {
            reject('Oops something is wrong');
        }
    }, 5000); });
}
fetchPost('Hurray').then(getPosts)["catch"](function (err) { return console.log(err); });
var date = new Date();
console.log("today is " + date.getDate());
console.log("now time is " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
//regex & exception handling(try,catch,throw,Error)
function regexTest(number, email) {
    var reg1 = /^[7-9]\d{9}$/;
    var reg2 = /^([a-zA-Z0-9]+)@([a-zA-Z0-9\.]+)$/;
    if (reg1.test(number) && reg2.test(email)) {
        console.log('valid mobile number and email id');
    }
    else {
        throw new Error('Invalid user name and email id');
    }
}
(function main() {
    try {
        regexTest('8886183899', 'upendravarma1993@gmail.com');
    }
    catch (error) {
        console.log(error.message);
    }
})();
