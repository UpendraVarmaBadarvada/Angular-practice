package com.in28minutes.mockito;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.stub;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class SpyTest {

	@Test
	// we mock a class and spy on an instance 
	public void creatingASpyOnArrayList() {
		List<String> list = new ArrayList<>();
		List<String> listSpy = spy(list);
		//adding stubs to the mocked instance created above 
		listSpy.add("Ranga");
		listSpy.add("in28Minutes");
		// verifies if a certain method is already called on an object 
		verify(listSpy).add("Ranga");
		verify(listSpy).add("in28Minutes");

		assertEquals(2, listSpy.size());
		assertEquals("Ranga", listSpy.get(0));
	}
}