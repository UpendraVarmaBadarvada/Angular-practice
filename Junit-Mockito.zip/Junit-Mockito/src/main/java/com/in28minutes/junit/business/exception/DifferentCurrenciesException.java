package com.in28minutes.junit.business.exception;

public class DifferentCurrenciesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
